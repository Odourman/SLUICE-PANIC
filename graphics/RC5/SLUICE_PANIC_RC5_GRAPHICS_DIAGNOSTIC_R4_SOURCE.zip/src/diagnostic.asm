    processor 6502
; Standalone F6 diagnostic. Identical bank image repeated four times, no switching.
VSYNC=$00
VBLANK=$01
WSYNC=$02
NUSIZ0=$04
NUSIZ1=$05
COLUP0=$06
COLUP1=$07
COLUPF=$08
COLUBK=$09
CTRLPF=$0A
REFP0=$0B
PF0=$0D
PF1=$0E
PF2=$0F
RESP0=$10
RESP1=$11
RESBL=$14
GRP0=$1B
GRP1=$1C
ENABL=$1F
HMP0=$20
HMP1=$21
HMBL=$24
HMOVE=$2A
HMCLR=$2B
INPT4=$0C
    IF TV = 1
VB=37
OS=30
WATER=$B6
FISH0=$1E
FISH1=$AE
OCT=$6E
SPARK=$1E
BLAST=$3E
    ELSE
VB=67
OS=50
WATER=$86
FISH0=$2E
FISH1=$9E
OCT=$CE
SPARK=$2E
BLAST=$4E
    ENDIF
Tick=$80
Stage=$81
Lane=$82
Ptr=$83
Cptr=$85
Kptr=$87
Phase=$89
Mid=$8A
Rail=$8B
EndRow=$8C
Mode=$8D
Kind=$8E
WaterNow=$8F
    ORG $F000
Reset:
    sei
    cld
    ldx #$FF
    txs
    lda #0
Clear:
    sta $00,x
    dex
    bne Clear
    sta $00
Frame:
    lda #2
    sta VBLANK
    sta VSYNC
    ldx #3
Sync:
    sta WSYNC
    dex
    bne Sync
    lda #0
    sta VSYNC
    inc Tick
    lda Stage
    cmp #7
    beq OverInput
    lda Tick
    and #$7F
    bne PhaseSet
    inc Stage
    jmp PhaseSet
OverInput:
    bit INPT4
    bmi PhaseSet
    lda #0
    sta Stage
    sta Tick
    inc Mode
PhaseSet:
    sta WSYNC
    lda Tick
    lsr
    lsr
    lsr
    and #3
    sta Phase
    lda #8
    sta REFP0
    lda #$0E
    sta COLUP0
    lda #$0A
    sta COLUPF
    lda #$21
    sta CTRLPF
    lda #0
    sta NUSIZ0
    sta NUSIZ1
    sta WSYNC
    lda #138
    ldx #0
    jsr Pos
    lda Tick
    and #$3F
    clc
    adc #24
    ldy Stage
    cpy #2
    bcc ObjPos
    lda #111
ObjPos:
    ldx #1
    jsr Pos
    lda #120
    ldx #4
    jsr Pos
    sta WSYNC
    sta HMOVE
    sta WSYNC
    sta HMCLR
    ; Clear display registers in blanking rather than on the first visible line.
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta PF0
    sta PF1
    sta PF2
    sta COLUBK
    ldx #VB-11
BlankLoop:
    sta WSYNC
    dex
    bne BlankLoop
    lda #0
    sta VBLANK
    lda Stage
    bne NotTitle
    ldy #0
    lda Mode
    and #1
    beq TitleGo
    ldy #32
TitleGo:
    tya
    clc
    adc #32
    sta EndRow
    jmp TextScreen
NotTitle:
    cmp #7
    bne Play
    ldy #64
    lda #96
    sta EndRow
    jmp TextScreen
Play:
    lda #$0E
    sta COLUPF
    lda #0
    sta CTRLPF
    ; fixed diagnostic six-digit HUD: 012500, repeated 4 rows each.
    ldy #96
    lda #101
    sta EndRow
    jsr HudText
    lda #0
    sta PF0
    sta PF1
    sta PF2
    ldx #4
HudPad:
    sta WSYNC
    dex
    bne HudPad
    lda #$21
    sta CTRLPF
    lda #$0A
    sta COLUPF
    lda #0
    sta Lane
LaneLoop:
    ; 4 setup lines: pointer, color, keeper and gate state. Then 36 draw lines.
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta PF0
    sta PF1
    sta PF2
    lda #4
    sta COLUBK
    sta WSYNC
    lda Stage
    asl
    asl
    clc
    adc Lane
    tax
    lda LaneKind,x
    sta Kind
    tay
    cmp #1
    beq Narrow
    lda #5
    bne SetWidth
Narrow:
    lda #0
SetWidth:
    sta NUSIZ1
    tya
    asl
    asl
    ora Phase
    tax
    lda SpriteLo,x
    sta Ptr
    lda ColorLo,x
    sta Cptr
    lda #>Sprites
    sta Ptr+1
    lda #>Colors
    sta Cptr+1
    sta WSYNC
    ldx Lane
    lda #<blank
    cpx #1
    bne KeepIt
    ldy Stage
    lda KeeperLo,y
KeepIt:
    sta Kptr
    lda #>Sprites
    sta Kptr+1
    lda Stage
    cmp #3
    bcc NormalRail
    sec
    sbc #3
    cmp Lane
    bcc NormalRail
    lda #0
    beq GateStore
NormalRail:
    lda #2
GateStore:
    sta Mid
    sta WSYNC
    lda #4
    sta Rail
    lda Mid
    bne RailOk
    lda #0
    sta Rail
RailOk:
    lda Rail
    sta COLUBK
    lda #$30
    sta PF0
    lda #$0A
    sta COLUPF
    sta WSYNC
    ; Two spare rail lines: select stable palette by replay, and damage pattern.
    lda Mode
    and #3
    tax
    lda Kind
    beq FishAColor
    cmp #3
    bne NoFishColor
    lda FishBLo,x
    bne SaveFishColor
FishAColor:
    lda FishALo,x
SaveFishColor:
    sta Cptr
NoFishColor:
    sta WSYNC
    lda Mode
    clc
    adc Lane
    and #3
    tax
    lda WaterColors,x
    sta WaterNow
    lda Mid
    bne RailIntact
    lda Phase
    and #1
    tax
    lda BrokenRail,x
    sta PF0
    lda #$24
    sta PF2
RailIntact:
    sta WSYNC
    ldx #2
RailTop:
    sta WSYNC
    dex
    bne RailTop
    lda WaterNow
    sta COLUBK
    lda #0
    sta PF2
    lda Mid
    sta ENABL
    ldx #4
CapTop:
    sta WSYNC
    dex
    bne CapTop
    ldy #0
ObjectRows:
    lda (Cptr),y
    sta COLUP1
    lda (Ptr),y
    sta GRP1
    lda (Kptr),y
    sta GRP0
    sta WSYNC
    sta WSYNC
    iny
    cpy #10
    bne ObjectRows
    lda #0
    sta GRP0
    sta GRP1
    ldx #4
CapBottom:
    sta WSYNC
    dex
    bne CapBottom
    lda #0
    sta ENABL
    lda Rail
    sta COLUBK
    ldx #4
RailBottom:
    sta WSYNC
    dex
    bne RailBottom
    inc Lane
    lda Lane
    cmp #4
    beq Footer
    jmp LaneLoop
Footer:
    lda #0
    sta PF0
    sta PF1
    sta PF2
    sta COLUBK
    ldx #8
FootLoop:
    sta WSYNC
    dex
    bne FootLoop
    jmp Overscan
TextScreen:
    lda #0
    sta CTRLPF
    lda #$0E
    sta COLUPF
    jsr Text6
    jmp Overscan
; Per-row raster schedule: left PF stores before visible; right stores after corresponding left segment.
; Prepare each row before WSYNC, then fixed register write phases; one initial alignment line is compensated in VBLANK. Emulator check mandatory.
    ALIGN 256
Text6:
    ldx #6
TLine:
    sta WSYNC
    lda Txt0,y
    sta PF0
    lda Txt1,y
    sta PF1
    lda Txt2,y
    sta PF2
    nop
    nop
    nop
    nop
    nop
    lda Txt3,y
    sta PF0
    lda Txt4,y
    sta PF1
    lda Txt5,y
    sta PF2
    dex
    bne TLine
    iny
    cpy EndRow
    bne Text6
    sta WSYNC
    rts
HudText:
    ldx #4
HLine:
    sta WSYNC
    lda Txt0,y
    sta PF0
    lda Txt1,y
    sta PF1
    lda Txt2,y
    sta PF2
    nop
    nop
    nop
    nop
    nop
    lda Txt3,y
    sta PF0
    lda Txt4,y
    sta PF1
    lda Txt5,y
    sta PF2
    dex
    bne HLine
    iny
    cpy EndRow
    bne HudText
    sta WSYNC
    rts
Overscan:
    lda #2
    sta VBLANK
    ldx #OS
OSLoop:
    sta WSYNC
    dex
    bne OSLoop
    jmp Frame
; Position during blanking. Separate HMOVE after all three objects are positioned.
Pos:
    sta WSYNC
    sec
PosLoop:
    sbc #15
    bcs PosLoop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    sta WSYNC
    rts
    include "diagnostic_data.inc"
    IF * > $FFF6
    ERR
    ENDIF
    ORG $FFFC
    .word Reset,Reset
