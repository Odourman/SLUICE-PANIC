from design import S,F,P
from pathlib import Path
p=Path(__file__).parent/'diagnostic_data.inc'
# Each kind has 4 phases. Bomb fuse only uses two rows of grayscale. No stripe on body.
kinds=[['fish_a','fish_b','fish_c','fish_b'],['bomb_a','bomb_b','bomb_a','bomb_b'],['oct_a','oct_b','oct_c','oct_b'],['fish_alt_a','fish_alt_b','fish_c','fish_alt_b'],['blast_0','blast_1','blast_2','blast_3'],['blast_3','blast_4','blast_4','blank'],['blank']*4]
keys=list(dict.fromkeys([k for g in kinds for k in g]+['keeper_idle','keeper_operate','keeper_error']))
assert len(keys)*10<=256
out=['    ALIGN 256','Sprites:']
for k in keys:out.append(k+': .byte '+','.join(f'${v:02X}' for v in S[k]))
out+=['    ALIGN 256','Colors:','CFish0: .byte '+','.join(['FISH0']*10),'CFish1: .byte '+','.join(['FISH1']*10),'COct: .byte '+','.join(['OCT']*10),'CBomb0: .byte 0,8,8,0,0,0,0,0,0,0','CBomb1: .byte 0,SPARK,8,0,0,0,0,0,0,0','CBlast: .byte '+','.join(['BLAST']*10),'CBlank: .byte '+','.join(['0']*10)]
out+=['    IF TV = 1']
for i,v in enumerate(P['NTSC']['fish']): out.append(f'CF{i}: .byte '+','.join([f'${v:02X}']*10))
out+=['    ELSE']
for i,v in enumerate(P['PAL']['fish']): out.append(f'CF{i}: .byte '+','.join([f'${v:02X}']*10))
out+=['    ENDIF']
cs=[['CFish0']*4,['CBomb0','CBomb1','CBomb0','CBomb1'],['COct']*4,['CFish1']*4,['CBlast']*4,['CBlast']*4,['CBlank']*4]
out+=['SpriteLo: .byte '+','.join('<'+k for g in kinds for k in g),'ColorLo: .byte '+','.join('<'+k for g in cs for k in g),'LaneKind: .byte '+','.join(map(str,[0,1,2,3,0,1,2,3,0,4,2,3,4,1,2,3,5,4,2,3,6,5,4,3,6,6,5,4,6,6,6,6]))]
out+=['FishALo: .byte <CF0,<CF2,<CF4,<CF0','FishBLo: .byte <CF1,<CF3,<CF5,<CF1','KeeperLo: .byte <keeper_idle,<keeper_operate,<keeper_error,<keeper_error,<keeper_error,<keeper_error,<keeper_error,<blank','BrokenRail: .byte $10,$20','    IF TV = 1','WaterColors: .byte $B6,$B8,$D6,$D8','    ELSE','WaterColors: .byte $86,$88,$A6,$A8','    ENDIF']
def screen(lines):
 a=[[0]*40 for _ in range(32)]
 for text,y in lines:
  start=(40-(len(text)*4-1))//2
  for i,c in enumerate(text):
   for j,bits in enumerate(F[c]):
    for b in range(3):a[y+j][start+4*i+b]=int(bool(bits&(4>>b)))
 return a
rows=screen([('SLUICE',1),('PANIC!',7),('CLASSIC',14),('BEST',20),('015300',26)])+screen([('SLUICE',1),('PANIC!',7),('EXPERT',14),('BEST',20),('015300',26)])+screen([('GAME OVER',1),('SCORE',8),('012500',14),('BEST',20),('015300',26)])+screen([('012500',0)])[:5]
def pack(bits):return [sum(bits[i]<<(4+i) for i in range(4)),sum(bits[4+i]<<(7-i) for i in range(8)),sum(bits[12+i]<<i for i in range(8))]
vals=[pack(r[:20])+pack(r[20:]) for r in rows]
for i in range(6):out+=['    ALIGN 256',f'Txt{i}: .byte '+','.join(str(row[i]) for row in vals)]
p.write_text('\n'.join(out)+'\n')
