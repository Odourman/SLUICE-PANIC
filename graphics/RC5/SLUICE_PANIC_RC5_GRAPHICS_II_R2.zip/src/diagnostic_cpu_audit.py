"""Actual-ROM CPU subset model, not TIA emulator. WSYNC boundaries and VSYNC edge timing."""
from pathlib import Path
from collections import defaultdict,Counter
import json

def run(tv):
 rom=Path(__file__).with_name(tv+'-1.bank').read_bytes(); mem=bytearray(128);pc=rom[-4]|rom[-3]<<8;a=x=y=0;sp=255;C=Z=N=0;t=0;edge=None;vs=0;result=defaultdict(Counter);maxseg=0;lastw=None;overruns=Counter();frames=0
 def read(addr):
  if addr&0x1000:return rom[addr&4095]
  if addr&0x80:return mem[addr&127]
  return 0x80 if addr&0x3f==12 else 0
 def push(v):
  nonlocal sp
  mem[sp&127]=v&255;sp=(sp-1)&255
 def pop():
  nonlocal sp
  sp=(sp+1)&255;return mem[sp&127]
 def nz(v):return int(v==0),int(bool(v&128))
 imm={0xa9:'a',0xa2:'x',0xa0:'y'};zp={0xa5:'a',0xa6:'x',0xa4:'y'}
 while frames<1024:
  here=pc;op=read(pc);pc+=1;cost=2;write=None
  if op in imm or op in zp:
   v=read(pc);pc+=1
   if op in zp:v=read(v);cost=3
   reg=(imm if op in imm else zp)[op]
   if reg=='a':a=v
   elif reg=='x':x=v
   else:y=v
   Z,N=nz(v)
  elif op in [0xbd,0xb9,0xb1]:
   if op==0xb1:
    q=read(pc);pc+=1;addr=read(q)|(read((q+1)&255)<<8);idx=y;cost=5
   else:
    addr=read(pc)|(read(pc+1)<<8);pc+=2;idx=x if op==0xbd else y;cost=4
   cost+=int((addr&0xff)+idx>255);a=read(addr+idx);Z,N=nz(a)
  elif op in [0x85,0x95]:
   addr=read(pc);pc+=1;cost=3 if op==0x85 else 4
   if op==0x95:addr=(addr+x)&255
   write=(addr,a)
  elif op==0xe6:
   addr=read(pc);pc+=1;v=(read(addr)+1)&255;Z,N=nz(v);cost=5;write=(addr,v)
  elif op in [0xc9,0xc5,0xc0,0xc4,0xe0]:
   v=read(pc);pc+=1
   if op in [0xc5,0xc4]:v=read(v);cost=3
   r=y if op in [0xc0,0xc4] else x if op==0xe0 else a
   C=int(r>=v);Z,N=nz((r-v)&255)
  elif op in [0x29,0x49,0x05,0x65,0x69,0xe9]:
   v=read(pc);pc+=1
   if op in [0x05,0x65]:v=read(v);cost=3
   if op==0x29:a&=v
   elif op==0x49:a^=v
   elif op==0x05:a|=v
   else:
    q=a+v+C if op!=0xe9 else a-v-(1-C)
    C=int(q>255) if op!=0xe9 else int(q>=0);a=q&255
   Z,N=nz(a)
  elif op in [0x4a,0x0a]:
   if op==0x4a:C=a&1;a>>=1
   else:C=(a>>7)&1;a=(a<<1)&255
   Z,N=nz(a)
  elif op in [0x98,0xaa,0xa8,0xca,0xc8]:
   if op==0x98:a=y;v=a
   elif op==0xaa:x=a;v=x
   elif op==0xa8:y=a;v=y
   elif op==0xca:x=(x-1)&255;v=x
   else:y=(y+1)&255;v=y
   Z,N=nz(v)
  elif op in [0xd0,0xf0,0x30,0x90,0xb0]:
   v=read(pc);pc+=1;v=v-256 if v&128 else v;cond={0xd0:not Z,0xf0:Z,0x30:N,0x90:not C,0xb0:C}[op]
   if cond:dest=(pc+v)&65535;cost=3+int(pc>>8!=dest>>8);pc=dest
  elif op in [0x20,0x4c]:
   addr=read(pc)|(read(pc+1)<<8);pc+=2
   if op==0x20:push((pc-1)>>8);push(pc-1);cost=6
   else:cost=3
   pc=addr
  elif op==0x60:pc=(pop()|(pop()<<8))+1;cost=6
  elif op==0x24:
   v=read(read(pc));pc+=1;Z=int((a&v)==0);N=int(bool(v&128));cost=3
  elif op==0x18:C=0
  elif op==0x38:C=1
  elif op==0x9a:sp=x
  elif op in [0x78,0xd8,0xea]:pass
  else:raise RuntimeError((hex(here),hex(op)))
  t+=cost
  if write:
   addr,v=write
   if addr&0x80:mem[addr&127]=v
   elif addr&0x3f==2:
    if lastw is not None:
     dt=t-lastw
     if edge is not None:maxseg=max(maxseg,dt)
     if dt>76 and edge is not None:overruns[(mem[1],hex(here))]+=1
    t=((t-1)//76+1)*76;lastw=t
   elif addr&0x3f==0:
    cur=v&2
    if cur and not vs:
     if edge is not None:result[prevstage][t//76-edge//76]+=1;frames+=1
     edge=t;prevstage=mem[1]
    vs=cur
 return {'region':tv,'frames':frames,'frame_line_counts_by_stage':{str(k):dict(v) for k,v in result.items()},'max_cycles_since_previous_wsync_release':maxseg,'overrun_sites':{f'stage{s} {p}':n for (s,p),n in overruns.items()},'limitations':'CPU subset, WSYNC and VSYNC model only; not TIA pixels, no emulator or physical proof'}
if __name__=='__main__':
 r=[run(tv) for tv in ['NTSC','PAL']];print(json.dumps(r,indent=2));Path(__file__).with_name('CPU_MODEL_RESULTS.json').write_text(json.dumps(r,indent=2)+'\n')
