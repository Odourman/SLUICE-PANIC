from pathlib import Path
import json, random, math
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent.parent; M=ROOT/'media'; M.mkdir(exist_ok=True)
# 8 TIA bits, top-down; each row repeated twice. MSB left.
S={
'fish_a':[0,0,0x10,0xbc,0x7d,0x7f,0xbc,0x80,0,0],
'fish_b':[0,0,0x10,0x3c,0xbd,0x7f,0x3c,0x40,0,0],
'fish_c':[0,0,0x10,0x5c,0x7d,0xff,0x5c,0x40,0,0],
'fish_alt_a':[0,0,0x18,0x94,0x7e,0x3f,0x7e,0x94,0,0],
'fish_alt_b':[0,0,0x18,0x54,0x7e,0xbf,0x7e,0x54,0,0],
'oct_a':[0,0,0x0c,0x9e,0x7f,0x1d,0x7e,0x8c,0,0],
'oct_b':[0,0,0x0c,0x5e,0xbf,0x1d,0xbe,0x4c,0,0],
'oct_c':[0,0,0x0c,0x1e,0xff,0x1d,0xfe,0x0c,0,0],
'bomb_a':[0,0x04,0x08,0x3c,0x7e,0x7e,0x7e,0x3c,0,0],
'bomb_b':[0,0x06,0x08,0x3c,0x7e,0x7e,0x7e,0x3c,0,0],
'blast_0':[0,0,0,0x18,0x3c,0x7e,0x3c,0x18,0,0],
'blast_1':[0,0x18,0x5a,0x3c,0x7e,0xff,0x7e,0x3c,0x5a,0x18],
'blast_2':[0x42,0x24,0x99,0x5a,0x24,0x24,0x5a,0x99,0x24,0x42],
'blast_3':[0x80,0x04,0x20,0x02,0x08,0x40,0x01,0x10,0x80,0x04],
'blast_4':[0,0,0x20,0,0x04,0,0x40,0,0x02,0],
'keeper_idle':[0x3c,0x7e,0x38,0x38,0x7c,0xfe,0x7c,0x38,0x28,0x6c],
'keeper_operate':[0x3c,0x7e,0x38,0x38,0x78,0xf8,0x7c,0x38,0x28,0x6c],
'keeper_error':[0x3c,0x7e,0x38,0xba,0x7c,0x38,0x38,0x28,0x44,0x82],
'blank':[0]*10}
for k in ['idle','operate','error']: S['keeper_'+k+'_mirror']=[int(f'{v:08b}'[::-1],2) for v in S['keeper_'+k]]
P={'NTSC':{'water':[0xb2,0xb4,0xd2,0xd4],'fish':[0x1e,0x3c,0xae,0xce,0x8e,0x6e],'oct':0x6e,'bomb':0,'fuse':8,'spark':0x1e,'blast':[0x1e,0x3e,0x3a,0x46,0x08]},'PAL':{'water':[0x82,0x84,0xa2,0xa4],'fish':[0x2e,0x4c,0x9e,0x5e,0xbe,0xce],'oct':0xce,'bomb':0,'fuse':8,'spark':0x2e,'blast':[0x2e,0x4e,0x4a,0x66,0x08]}}
# Approximate RGB presentation only; not calibrated emulator palettes.
RGB={'water':['#2d5180','#3c6390','#305d68','#46767c'],'fish':['#f5da63','#f6a35f','#7ce5d5','#aee379','#a8bfff','#efb5fa'],'oct':'#dca4f5','bomb':'#000000','fuse':'#b4b4b4','spark':'#ffe06a','blast':['#fff0a0','#ffb53d','#fa7538','#ce5349','#9f9a9a'],'wall':'#777d80','gate':'#c7ccca','keeper':'#f2f1e5'}
F={'A':[2,5,7,5,5],'B':[6,5,6,5,6],'C':[7,4,4,4,7],'E':[7,4,6,4,7],'G':[7,4,5,5,7],'I':[7,2,2,2,7],'L':[4,4,4,4,7],'M':[5,7,7,5,5],'N':[5,7,7,7,5],'O':[7,5,5,5,7],'P':[7,5,7,4,4],'R':[6,5,6,5,5],'S':[7,4,7,1,7],'T':[7,2,2,2,2],'U':[5,5,5,5,7],'V':[5,5,5,5,2],'X':[5,5,2,5,5],'!':[2,2,2,0,2],' ':[0]*5,'0':[7,5,5,5,7],'1':[2,6,2,2,7],'2':[7,1,7,4,7],'3':[7,1,7,1,7],'4':[5,5,7,1,1],'5':[7,4,7,1,7],'6':[7,4,7,5,7],'7':[7,1,2,2,2],'8':[7,5,7,5,7],'9':[7,5,7,1,7]}
def sprite(im,key,x,y,color,width=1):
 d=ImageDraw.Draw(im); mask=S[key]
 for j,v in enumerate(mask):
  c=color[j] if isinstance(color,list) else color
  for b in range(8):
   if v&(128>>b):d.rectangle((x+b*width,y+2*j,x+(b+1)*width-1,y+2*j+1),fill=c)
def words(im,t,y,scale=4,col='#e8ead7',h=3):
 d=ImageDraw.Draw(im); x=(160-(len(t)*4-1)*scale)//2
 for ch in t:
  for j,v in enumerate(F[ch]):
   for b in range(3):
    if v&(4>>b):d.rectangle((x+b*scale,y+j*h,x+(b+1)*scale-1,y+(j+1)*h-1),fill=col)
  x+=4*scale
def bombcolors(i):return [RGB['bomb'],RGB['spark'] if i%2 else RGB['fuse'],RGB['fuse']]+[RGB['bomb']]*7
def view(im):return im.resize((320,240),Image.Resampling.NEAREST)
def save(im,n):im.save(M/(n+'_native.png'));view(im).save(M/(n+'_320x240.png'))
def title(expert=False,over=False):
 im=Image.new('RGB',(160,192),'#101c2a'); d=ImageDraw.Draw(im)
 if over:
  words(im,'GAME OVER',18,4,'#ffad63',5);words(im,'SCORE',64,3,'#c5c6bf');words(im,'012500',84,4,'#eee9cd',4);words(im,'BEST',122,3,'#c5c6bf');words(im,'015300',142,4,'#eee9cd',4)
 else:
  words(im,'SLUICE',15,4,'#f5d76b',5);words(im,'PANIC!',44,4,'#f5d76b',5);d.rectangle((8,79,151,81),fill='#777d80');sprite(im,'fish_a',26,86,RGB['fish'][2],2);sprite(im,'bomb_a',70,86,bombcolors(0),2);sprite(im,'oct_a',114,86,RGB['oct'],2);words(im,'EXPERT' if expert else 'CLASSIC',126,4,'#e8ead7',4);words(im,'BEST',155,2,'#b7c1bf');words(im,'015300',173,3,'#e8ead7')
 return im
def board(t=0,stage='swim',p=0,theme=1):
 im=Image.new('RGB',(160,192),'#151c24');d=ImageDraw.Draw(im); words(im,'012500',4,3,'#f0efe2',3)
 for x in range(3 if stage=='swim' else 2 if stage=='local' else 0):d.rectangle((8+x*7,7,12+x*7,16),fill=RGB['keeper'])
 for lane in range(4):
  y=24+40*lane;water=RGB['water'][theme];damage=max(-1,p-lane*2) if stage=='collapse' else -1
  d.rectangle((0,y+8,159,y+35),fill=water);d.rectangle((0,y+8,159,y+9),fill=RGB['water'][(theme+1)%4]);d.rectangle((0,y+34,159,y+35),fill=RGB['water'][(theme+1)%4]);d.rectangle((0,y,159,y+6),fill=RGB['wall']);d.rectangle((0,y+36,159,y+39),fill=RGB['wall']);d.rectangle((0,y+7,7,y+35),fill='#626b71')
  if damage>=3:
   rng=random.Random(14+lane);d.rectangle((0,y,159,y+6),fill='#151c24');d.rectangle((0,y+36,159,y+39),fill='#151c24')
   for _ in range(14):
    x=rng.randrange(0,39)*4; yy=y+rng.choice([0,3,36]);d.rectangle((x,yy,x+3,yy+2),fill=RGB['wall'])
  if damage<2:
   d.rectangle((120,y+8,123,y+11),fill=RGB['gate']);d.rectangle((120,y+32,123,y+35),fill=RGB['gate'])
   if lane%2==0:d.rectangle((120,y+12,123,y+31),fill=RGB['gate'])
  elif damage<5:
   d.rectangle((120,y+9,123,y+12),fill=RGB['gate']);d.rectangle((116,y+25,119,y+28),fill=RGB['gate'])
  seq=['a','b','c','b'];idx=seq[(t//3)%4]; x=15+(t*2+lane*24)%94
  if stage=='local' and lane==1 or stage=='collapse' and damage>=0:
   z=min(4,p if stage=='local' else damage);sprite(im,'blast_'+str(z),116,y+12,RGB['blast'][z],2)
  elif stage!='collapse' or damage<0:
   if lane==1:sprite(im,'bomb_'+('b' if t//4%2 else 'a'),x,y+12,bombcolors(t//4))
   elif lane==2:sprite(im,'oct_'+idx,x,y+12,RGB['oct'],2)
   else:sprite(im,'fish_'+idx,x,y+12,RGB['fish'][0 if lane==0 else 2],2)
  if lane==1 and stage!='collapse':sprite(im,'keeper_error_mirror' if stage=='local' else 'keeper_idle_mirror',137,y+12,RGB['keeper'])
 return im
def gif(name,frames,ms):
 out=[view(i) for i in frames];out[0].save(M/(name+'.gif'),save_all=True,append_images=out[1:],duration=ms,loop=0,disposal=2)
def strip(name,keys,colors):
 im=Image.new('RGB',(len(keys)*80,94),'#253e60');d=ImageDraw.Draw(im);font=ImageFont.load_default()
 for i,(k,c) in enumerate(zip(keys,colors)):
  b=Image.new('RGB',(8,20),'#253e60');sprite(b,k,0,0,c);im.paste(b.resize((64,80),Image.Resampling.NEAREST),(i*80+8,0));d.text((i*80+6,81),str(i+1),font=font,fill='white')
 im.save(M/(name+'.png'))
def main():
 (ROOT/'src'/'sprites.json').write_text(json.dumps({'bitmaps':S,'tia_palettes':P,'row_repeat':2,'rgb_approximation':RGB},indent=2))
 (ROOT/'src'/'graphics_data.inc').write_text('; top-down, repeat each row twice\n'+''.join(k+':\n    .byte '+','.join(f'${x:02X}' for x in v)+'\n' for k,v in S.items())+''.join(f'{tv}_fish_colors: .byte '+','.join(f'${x:02X}' for x in v['fish'])+'\n' for tv,v in P.items()))
 save(board(7),'playfield_MOCKUP');save(title(),'title_classic_MOCKUP');save(title(True),'title_expert_MOCKUP');save(title(over=True),'gameover_MOCKUP');save(board(2,'local',1),'local_loss_MOCKUP');save(board(2,'collapse',5),'collapse_MOCKUP')
 strip('fish_options', ['fish_a','fish_b','fish_c','fish_alt_a','fish_alt_b'],[RGB['fish'][0]]*5);strip('octopus_frames',['oct_a','oct_b','oct_c'],[RGB['oct']]*3);strip('bomb_frames',['bomb_a','bomb_b'],[bombcolors(0),bombcolors(1)]);strip('blast_frames',['blast_'+str(i) for i in range(5)],RGB['blast']);strip('keeper_before_after',[f'keeper_{p}{m}' for p in ['idle','operate','error'] for m in ['', '_mirror']],[RGB['keeper']]*6)
 gif('swim_MOCKUP',[board(i) for i in range(36)],90);gif('local_explosion_MOCKUP',[board(2,'local',i) for i in range(5)]+[board(6)],120);gif('collapse_MOCKUP',[board(2,'collapse',i) for i in range(12)]+[title(over=True)]*12,150)
 for name,keys,colors in [('fish',['fish_a','fish_b','fish_c','fish_b'],[RGB['fish'][0]]*4),('octopus',['oct_a','oct_b','oct_c','oct_b'],[RGB['oct']]*4),('bomb',['bomb_a','bomb_b'],[bombcolors(0),bombcolors(1)]),('explosion',['blast_'+str(i) for i in range(5)],RGB['blast'])]:
  frames=[]
  for k,c in zip(keys,colors):
   im=Image.new('RGB',(8,20),'#3c6390');sprite(im,k,0,0,c);frames.append(im.resize((128,160),Image.Resampling.NEAREST))
  frames[0].save(M/(name+'_DETAIL.gif'),save_all=True,append_images=frames[1:],duration=130,loop=0,disposal=2)
if __name__=='__main__':main()
