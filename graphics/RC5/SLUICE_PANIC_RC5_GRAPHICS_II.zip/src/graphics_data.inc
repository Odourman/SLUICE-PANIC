; top-down, repeat each row twice
fish_a:
    .byte $00,$00,$10,$BC,$7D,$7F,$BC,$80,$00,$00
fish_b:
    .byte $00,$00,$10,$3C,$BD,$7F,$3C,$40,$00,$00
fish_c:
    .byte $00,$00,$10,$5C,$7D,$FF,$5C,$40,$00,$00
fish_alt_a:
    .byte $00,$00,$18,$94,$7E,$3F,$7E,$94,$00,$00
fish_alt_b:
    .byte $00,$00,$18,$54,$7E,$BF,$7E,$54,$00,$00
oct_a:
    .byte $00,$00,$0C,$9E,$7F,$1D,$7E,$8C,$00,$00
oct_b:
    .byte $00,$00,$0C,$5E,$BF,$1D,$BE,$4C,$00,$00
oct_c:
    .byte $00,$00,$0C,$1E,$FF,$1D,$FE,$0C,$00,$00
bomb_a:
    .byte $00,$04,$08,$3C,$7E,$7E,$7E,$3C,$00,$00
bomb_b:
    .byte $00,$06,$08,$3C,$7E,$7E,$7E,$3C,$00,$00
blast_0:
    .byte $00,$00,$00,$18,$3C,$7E,$3C,$18,$00,$00
blast_1:
    .byte $00,$18,$5A,$3C,$7E,$FF,$7E,$3C,$5A,$18
blast_2:
    .byte $42,$24,$99,$5A,$24,$24,$5A,$99,$24,$42
blast_3:
    .byte $80,$04,$20,$02,$08,$40,$01,$10,$80,$04
blast_4:
    .byte $00,$00,$20,$00,$04,$00,$40,$00,$02,$00
keeper_idle:
    .byte $3C,$7E,$38,$38,$7C,$FE,$7C,$38,$28,$6C
keeper_operate:
    .byte $3C,$7E,$38,$38,$78,$F8,$7C,$38,$28,$6C
keeper_error:
    .byte $3C,$7E,$38,$BA,$7C,$38,$38,$28,$44,$82
blank:
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00
keeper_idle_mirror:
    .byte $3C,$7E,$1C,$1C,$3E,$7F,$3E,$1C,$14,$36
keeper_operate_mirror:
    .byte $3C,$7E,$1C,$1C,$1E,$1F,$3E,$1C,$14,$36
keeper_error_mirror:
    .byte $3C,$7E,$1C,$5D,$3E,$1C,$1C,$14,$22,$41
NTSC_fish_colors: .byte $1E,$3C,$AE,$CE,$8E,$6E
PAL_fish_colors: .byte $2E,$4C,$9E,$5E,$BE,$CE
